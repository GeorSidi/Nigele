package cse.nigile.softdevi.service;

import cse.nigile.softdevi.entities.Role;

public interface RoleService {
	
	public void saveRole(Role role);
}
