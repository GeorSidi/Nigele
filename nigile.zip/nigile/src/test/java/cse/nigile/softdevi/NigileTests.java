package cse.nigile.softdevi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NigileTests {

	@Test
	void contextLoads() {
	}

}
